
const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || `خطای ${response.status}`);
  }

  return data;
}

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 3500);
}

function formatBytes(value) {
  let bytes = Number(value || 0);
  if (!Number.isFinite(bytes) || bytes < 0) bytes = 0;
  if (bytes < 1024) return `${bytes} B`;

  const units = ["KB", "MB", "GB", "TB", "PB"];
  let i = -1;
  do {
    bytes /= 1024;
    i++;
  } while (bytes >= 1024 && i < units.length - 1);

  return `${bytes.toFixed(2)} ${units[i]}`;
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString("fa-IR");
}

function showAuthMessage(message) {
  $("#authMessage").textContent = message || "";
}

async function checkSetup() {
  try {
    const data = await api("/api/setup/status");
    $("#setupForm").classList.toggle("hidden", !data.setupRequired);
    $("#loginForm").classList.toggle("hidden", data.setupRequired);
  } catch (error) {
    showAuthMessage(error.message);
  }
}

async function showApp(admin) {
  $("#auth").classList.add("hidden");
  $("#app").classList.remove("hidden");
  $("#adminName").textContent = admin?.username || "مدیر";

  try {
    const settings = await api("/api/settings");
    if (settings.theme === "light" || settings.theme === "dark") {
      document.documentElement.dataset.theme = settings.theme;
    }
  } catch {}

  await loadDashboard();
  await loadUsers();
}

async function checkLogin() {
  try {
    const data = await api("/api/me");
    await showApp(data.admin);
  } catch {
    $("#auth").classList.remove("hidden");
    $("#app").classList.add("hidden");
    await checkSetup();
  }
}

$("#setupForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);

  try {
    await api("/api/setup", {
      method: "POST",
      body: JSON.stringify({
        username: form.get("username"),
        password: form.get("password")
      })
    });

    event.currentTarget.reset();
    $("#setupForm").classList.add("hidden");
    $("#loginForm").classList.remove("hidden");
    showAuthMessage("مدیر ساخته شد؛ اکنون وارد شو.");
  } catch (error) {
    showAuthMessage(error.message);
  }
});

$("#loginForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);

  try {
    const data = await api("/api/login", {
      method: "POST",
      body: JSON.stringify({
        username: form.get("username"),
        password: form.get("password")
      })
    });

    event.currentTarget.reset();
    showAuthMessage("");
    await showApp(data.admin);
  } catch (error) {
    showAuthMessage(error.message);
  }
});

$("#logout").addEventListener("click", async () => {
  try {
    await api("/api/logout", { method: "POST" });
  } catch {}

  $("#app").classList.add("hidden");
  $("#auth").classList.remove("hidden");
  await checkSetup();
});

$("#minimize").addEventListener("click", () => {
  document.body.classList.toggle("minimized");
});

$$("[data-page]").forEach(button => {
  button.addEventListener("click", async () => {
    const page = button.dataset.page;

    $$("[data-page]").forEach(item => item.classList.toggle("active", item === button));
    $$(".page").forEach(item => item.classList.add("hidden"));
    $(`#page-${page}`).classList.remove("hidden");

    $("#pageTitle").textContent = {
      dashboard: "داشبورد",
      users: "مدیریت کاربران",
      settings: "تنظیمات"
    }[page] || "NEXUS PRO";

    if (page === "dashboard") await loadDashboard();
    if (page === "users") await loadUsers();
    if (page === "settings") await loadSettings();
  });
});

$("#themeToggle").addEventListener("click", async () => {
  const current = document.documentElement.dataset.theme || "dark";
  const theme = current === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = theme;

  try {
    await api("/api/settings", {
      method: "PUT",
      body: JSON.stringify({ theme })
    });
  } catch (error) {
    toast(error.message);
  }
});

$("#refresh").addEventListener("click", loadDashboard);

async function loadDashboard() {
  try {
    const data = await api("/api/dashboard");

    $("#totalUsers").textContent = Number(data.summary.users || 0).toLocaleString("fa-IR");
    $("#activeUsers").textContent = Number(data.summary.enabled || 0).toLocaleString("fa-IR");
    $("#trafficUsed").textContent = formatBytes(data.summary.totalUsedBytes);

    $("#xrayState").textContent = data.xray.running ? "اجرا شده" : "متوقف";
    $("#xrayInfo").textContent = data.xray.error || "وضعیت فرایند";
    $("#xrayBadge").textContent = data.xray.running ? "فرایند فعال" : "متوقف";
    $("#xrayBadge").className = "status-label " + (data.xray.running ? "good" : "");

    $("#memoryRss").textContent = formatBytes(data.memory.rss);
    $("#memoryHeap").textContent = formatBytes(data.memory.heapUsed);
    $("#uptime").textContent = `${Math.floor(data.uptimeSeconds / 3600)} ساعت`;
    $("#nodeVersion").textContent = data.node;
  } catch (error) {
    toast(error.message);
  }
}

$("#openUserForm").addEventListener("click", () => {
  $("#userForm").classList.toggle("hidden");
});

$("#cancelUserForm").addEventListener("click", () => {
  $("#userForm").classList.add("hidden");
});

$("#userForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);

  try {
    await api("/api/users", {
      method: "POST",
      body: JSON.stringify({
        name: form.get("name"),
        quotaGB: Number(form.get("quotaGB")),
        days: Number(form.get("days"))
      })
    });

    event.currentTarget.reset();
    $("#userForm").classList.add("hidden");
    toast("درخواست ایجاد کاربر انجام شد");
    await loadUsers();
    await loadDashboard();
  } catch (error) {
    toast(error.message);
  }
});

async function loadUsers() {
  const body = $("#usersTable");
  body.innerHTML = "<tr><td colspan='6'>در حال بارگذاری...</td></tr>";

  try {
    const users = await api("/api/users");
    body.replaceChildren();

    if (!users.length) {
      body.innerHTML = "<tr><td colspan='6'>هنوز کاربری ساخته نشده است.</td></tr>";
      return;
    }

    for (const user of users) {
      const tr = document.createElement("tr");

      const name = document.createElement("td");
      name.textContent = user.name;

      const uuid = document.createElement("td");
      uuid.textContent = user.uuid;

      const quota = document.createElement("td");
      quota.textContent = `${formatBytes(user.usedBytes)} / ${formatBytes(user.quotaBytes)}`;

      const expiry = document.createElement("td");
      expiry.textContent = formatDate(user.expiresAt);

      const status = document.createElement("td");
      status.textContent = user.enabled ? "فعال" : "غیرفعال";

      const actions = document.createElement("td");

      const toggle = document.createElement("button");
      toggle.className = "table-action";
      toggle.textContent = user.enabled ? "غیرفعال‌کردن" : "فعال‌کردن";
      toggle.addEventListener("click", async () => {
        try {
          await api(`/api/users/${encodeURIComponent(user.id)}`, {
            method: "PATCH",
            body: JSON.stringify({ enabled: !user.enabled })
          });
          await loadUsers();
          await loadDashboard();
          toast("وضعیت کاربر تغییر کرد");
        } catch (error) {
          toast(error.message);
        }
      });

      const remove = document.createElement("button");
      remove.className = "table-action danger";
      remove.textContent = "حذف";
      remove.addEventListener("click", async () => {
        if (!confirm(`کاربر «${user.name}» حذف شود؟`)) return;

        try {
          await api(`/api/users/${encodeURIComponent(user.id)}`, { method: "DELETE" });
          await loadUsers();
          await loadDashboard();
          toast("کاربر حذف شد");
        } catch (error) {
          toast(error.message);
        }
      });

      actions.append(toggle, remove);
      tr.append(name, uuid, quota, expiry, status, actions);
      body.append(tr);
    }
  } catch (error) {
    body.innerHTML = "";
    toast(error.message);
  }
}

async function loadSettings() {
  try {
    const settings = await api("/api/settings");
    const form = $("#settingsForm");

    form.elements.panelName.value = settings.panelName || "NEXUS PRO";
    form.elements.wsEnabled.checked = Boolean(settings.inbounds?.ws?.enabled);
    form.elements.wsPath.value = settings.inbounds?.ws?.path || "/nexus-ws";
    form.elements.xhttpEnabled.checked = Boolean(settings.inbounds?.xhttp?.enabled);
    form.elements.xhttpPath.value = settings.inbounds?.xhttp?.path || "/nexus-xhttp";
  } catch (error) {
    toast(error.message);
  }
}

$("#settingsForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;

  try {
    await api("/api/settings", {
      method: "PUT",
      body: JSON.stringify({
        panelName: form.elements.panelName.value,
        inbounds: {
          ws: {
            enabled: form.elements.wsEnabled.checked,
            path: form.elements.wsPath.value
          },
          xhttp: {
            enabled: form.elements.xhttpEnabled.checked,
            path: form.elements.xhttpPath.value
          }
        }
      })
    });

    toast("تنظیمات ذخیره شد");
    await loadDashboard();
  } catch (error) {
    toast(error.message);
  }
});

checkLogin();
