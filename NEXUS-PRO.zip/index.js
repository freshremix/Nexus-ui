
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const path = require("path");
const crypto = require("crypto");
const { randomUUID } = require("crypto");

const {
  getDB,
  persist,
  createInitialAdmin,
  publicAdmin
} = require("./lib/database");

const {
  verifyAdmin,
  requireAuth,
  requireAdmin
} = require("./lib/auth");

const xray = require("./lib/xray");
const traffic = require("./lib/traffic");

const app = express();
const PORT = Number(process.env.PORT || 8080);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be set to a random secret of at least 32 characters.");
  process.exit(1);
}

app.disable("x-powered-by");
app.set("trust proxy", 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(session({
  name: "nexus.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    maxAge: 8 * 60 * 60 * 1000
  }
}));

app.use(express.static(path.join(__dirname, "public"), {
  index: "index.html",
  dotfiles: "deny"
}));

function validString(value, min, max) {
  return typeof value === "string" &&
    value.trim().length >= min &&
    value.trim().length <= max;
}

function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

app.get("/api/setup/status", (req, res) => {
  const db = getDB();
  res.json({ setupRequired: !db.setupComplete });
});

app.post("/api/setup", asyncRoute(async (req, res) => {
  const db = getDB();
  if (db.setupComplete || db.admins.length) {
    return res.status(409).json({ error: "راه‌اندازی اولیه قبلاً انجام شده است" });
  }

  const { username, password } = req.body;
  if (!validString(username, 3, 40) || !validString(password, 12, 200)) {
    return res.status(400).json({
      error: "نام کاربری حداقل ۳ و رمز عبور حداقل ۱۲ کاراکتر باشد"
    });
  }

  await createInitialAdmin(username.trim(), password);
  res.json({ ok: true });
}));

app.post("/api/login", asyncRoute(async (req, res) => {
  const { username, password } = req.body;
  if (!validString(username, 1, 80) || !validString(password, 1, 200)) {
    return res.status(400).json({ error: "اطلاعات ورود نامعتبر است" });
  }

  const admin = await verifyAdmin(username.trim(), password);
  if (!admin) return res.status(401).json({ error: "نام کاربری یا رمز اشتباه است" });

  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "خطا در ایجاد نشست" });
    req.session.admin = admin;
    res.json({ ok: true, admin });
  });
}));

app.post("/api/logout", requireAuth, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("nexus.sid", { httpOnly: true, sameSite: "strict" });
    res.json({ ok: true });
  });
});

app.get("/api/me", requireAuth, (req, res) => {
  res.json({ admin: req.session.admin });
});

app.get("/api/dashboard", requireAuth, (req, res) => {
  traffic.refreshExpiredUsers();
  const db = getDB();

  res.json({
    panelName: db.settings.panelName,
    summary: traffic.getTrafficSummary(),
    xray: xray.status(),
    uptimeSeconds: Math.floor(process.uptime()),
    memory: process.memoryUsage(),
    platform: process.platform,
    node: process.version
  });
});

app.get("/api/users", requireAuth, (req, res) => {
  const db = getDB();
  res.json(db.users.map(u => ({
    id: u.id,
    name: u.name,
    uuid: u.uuid,
    enabled: u.enabled,
    quotaBytes: u.quotaBytes,
    usedBytes: u.usedBytes,
    expiresAt: u.expiresAt,
    createdAt: u.createdAt
  })));
});

app.post("/api/users", requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const db = getDB();
  const { name, quotaGB, days } = req.body;

  if (!validString(name, 1, 80)) {
    return res.status(400).json({ error: "نام کاربر نامعتبر است" });
  }

  const quota = Number(quotaGB);
  const validity = Number(days);

  if (!Number.isFinite(quota) || quota < 0 || quota > 100000 ||
      !Number.isInteger(validity) || validity < 1 || validity > 3650) {
    return res.status(400).json({ error: "سهمیه یا مدت اعتبار نامعتبر است" });
  }

  const user = {
    id: randomUUID(),
    name: name.trim(),
    uuid: randomUUID(),
    enabled: true,
    quotaBytes: Math.floor(quota * 1024 ** 3),
    usedBytes: 0,
    expiresAt: new Date(Date.now() + validity * 86400000).toISOString(),
    createdAt: new Date().toISOString()
  };

  db.users.push(user);
  persist();

  try {
    await xray.restart(db);
    res.status(201).json({ ok: true, user });
  } catch (err) {
    user.enabled = false;
    persist();
    res.status(500).json({
      error: "کاربر ذخیره شد اما راه‌اندازی Xray ناموفق بود",
      detail: err.message
    });
  }
}));

app.patch("/api/users/:id", requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const db = getDB();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: "کاربر پیدا نشد" });

  if (typeof req.body.enabled === "boolean") user.enabled = req.body.enabled;

  if (req.body.name !== undefined) {
    if (!validString(req.body.name, 1, 80)) {
      return res.status(400).json({ error: "نام نامعتبر است" });
    }
    user.name = req.body.name.trim();
  }

  if (req.body.quotaGB !== undefined) {
    const quota = Number(req.body.quotaGB);
    if (!Number.isFinite(quota) || quota < 0 || quota > 100000) {
      return res.status(400).json({ error: "سهمیه نامعتبر است" });
    }
    user.quotaBytes = Math.floor(quota * 1024 ** 3);
  }

  if (req.body.days !== undefined) {
    const days = Number(req.body.days);
    if (!Number.isInteger(days) || days < 1 || days > 3650) {
      return res.status(400).json({ error: "مدت اعتبار نامعتبر است" });
    }
    user.expiresAt = new Date(Date.now() + days * 86400000).toISOString();
  }

  persist();
  await xray.restart(db);
  res.json({ ok: true });
}));

app.delete("/api/users/:id", requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const db = getDB();
  const index = db.users.findIndex(u => u.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: "کاربر پیدا نشد" });

  db.users.splice(index, 1);
  persist();
  await xray.restart(db);
  res.json({ ok: true });
}));

app.get("/api/settings", requireAuth, requireAdmin, (req, res) => {
  res.json(getDB().settings);
});

app.put("/api/settings", requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const db = getDB();
  const incoming = req.body;

  if (incoming.panelName !== undefined) {
    if (!validString(incoming.panelName, 1, 80)) {
      return res.status(400).json({ error: "نام پنل نامعتبر است" });
    }
    db.settings.panelName = incoming.panelName.trim();
  }

  if (incoming.theme === "dark" || incoming.theme === "light") {
    db.settings.theme = incoming.theme;
  }

  if (incoming.inbounds && typeof incoming.inbounds === "object") {
    for (const type of ["ws", "xhttp"]) {
      const value = incoming.inbounds[type];
      if (!value) continue;

      if (typeof value.enabled === "boolean") {
        db.settings.inbounds[type].enabled = value.enabled;
      }
      if (value.path !== undefined) {
        if (!validString(value.path, 1, 100) || !value.path.startsWith("/")) {
          return res.status(400).json({ error: "مسیر inbound باید با / شروع شود" });
        }
        db.settings.inbounds[type].path = value.path;
      }
    }
  }

  if (Array.isArray(incoming.routing)) {
    if (incoming.routing.length > 100) {
      return res.status(400).json({ error: "تعداد قوانین بیش از حد است" });
    }
    db.settings.routing = incoming.routing.map(r => ({
      enabled: Boolean(r.enabled),
      domain: Array.isArray(r.domain) ? r.domain.filter(v => typeof v === "string").slice(0, 50) : [],
      ip: Array.isArray(r.ip) ? r.ip.filter(v => typeof v === "string").slice(0, 50) : [],
      outboundTag: ["direct", "blocked"].includes(r.outboundTag) ? r.outboundTag : "direct"
    }));
  }

  persist();
  await xray.restart(db);
  res.json({ ok: true });
}));

app.get("/api/config/:id", requireAuth, (req, res) => {
  const db = getDB();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: "کاربر پیدا نشد" });

  res.json({
    uuid: user.uuid,
    name: user.name,
    wsPath: db.settings.inbounds.ws.path,
    xhttpPath: db.settings.inbounds.xhttp.path,
    note: "برای ساخت لینک اتصال باید آدرس عمومی و TLS واقعی سرور تعیین شود."
  });
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, uptime: Math.floor(process.uptime()) });
});

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "خطای داخلی سرور" });
});

const server = app.listen(PORT, "0.0.0.0", () => {
  console.log(`NEXUS PRO listening on ${PORT}`);
});

async function startXray() {
  try {
    await xray.restart(getDB());
    console.log("Xray started");
  } catch (err) {
    console.error("Xray startup failed:", err.message);
  }
}

startXray();

const timer = setInterval(() => {
  try {
    traffic.refreshExpiredUsers();
  } catch (err) {
    console.error("Traffic check failed:", err.message);
  }
}, 60_000);

function shutdown() {
  clearInterval(timer);
  server.close(() => {
    xray.stop();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref();
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
